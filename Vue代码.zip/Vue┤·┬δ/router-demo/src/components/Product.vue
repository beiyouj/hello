<template>
<h3>商品{{id}}</h3>
</template>

<script>
export default {
    props:["id"]
}
</script>